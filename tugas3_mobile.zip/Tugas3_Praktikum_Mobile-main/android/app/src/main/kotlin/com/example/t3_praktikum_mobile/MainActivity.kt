package com.example.t3_praktikum_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
