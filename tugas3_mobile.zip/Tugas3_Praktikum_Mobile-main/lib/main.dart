import 'package:flutter/material.dart';

import 'calculatorbmi.dart';

void main() {
  runApp(const BMICalculatorApp());
}

class BMICalculatorApp extends StatelessWidget {
  const BMICalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'KALKULATOR BMI',
      theme: ThemeData(primarySwatch: Colors.blue, useMaterial3: true),
      home: const BMICalculatorScreen(),
    );
  }
}
